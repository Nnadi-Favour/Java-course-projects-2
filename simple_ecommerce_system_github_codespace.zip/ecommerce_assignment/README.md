# Creating a Simple E-commerce System

This project is a simple Java e-commerce system demonstrating Java packages,
import statements, encapsulation, input validation, shopping cart operations,
order placement, and error handling.

## Project Structure

```text
src/
├── EcommerceMain.java
└── com/
    └── ecommerce/
        ├── Product.java
        ├── Customer.java
        └── orders/
            └── Order.java
```

## How to Run in GitHub Codespaces

1. Open the repository in GitHub Codespaces.
2. Make sure the four `.java` files are inside the folders shown above.
3. Open the terminal in VS Code.
4. Run:

   ```bash
   rm -rf out
   mkdir out
   javac -d out src/com/ecommerce/Product.java src/com/ecommerce/Customer.java src/com/ecommerce/orders/Order.java src/EcommerceMain.java
   ```

5. If compilation succeeds, run:

   ```bash
   java -cp out EcommerceMain
   ```

6. The program will display products, customer information, shopping-cart
   activity, the calculated total, an order summary, updated stock, and an
   example of handled invalid order placement.

## Screenshot for Submission

After running the program, take a screenshot showing the terminal output.
Include that screenshot in the final MS Word or PDF submission as required
by the assignment.

## Verification

The source files in this package were compiled and executed before delivery.
Compilation return code: 0
Program return code: 0

## Note on the implementation

The shopping cart stores one entry per added product, so adding the same
product twice represents a quantity of two. The assignment asks for a
simple system, so this approach keeps the code easy to understand while
still demonstrating the required operations.
