package com.ecommerce;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.ecommerce.orders.Order;

public class Customer {
    private final String customerId;
    private String name;
    private final List<Product> shoppingCart;

    public Customer(String customerId, String name) {
        if (customerId == null || customerId.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer ID cannot be empty.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be empty.");
        }

        this.customerId = customerId;
        this.name = name;
        this.shoppingCart = new ArrayList<>();
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be empty.");
        }
        this.name = name;
    }

    public List<Product> getShoppingCart() {
        return Collections.unmodifiableList(shoppingCart);
    }

    public void addProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }
        if (!product.isInStock()) {
            throw new IllegalArgumentException("Product is out of stock.");
        }
        shoppingCart.add(product);
    }

    public void removeProduct(String productId) {
        boolean removed = shoppingCart.removeIf(
                product -> product.getProductId().equals(productId));

        if (!removed) {
            throw new IllegalArgumentException("Product is not in the shopping cart.");
        }
    }

    public double calculateTotal() {
        double total = 0.0;
        for (Product product : shoppingCart) {
            total += product.getPrice();
        }
        return total;
    }

    public Order placeOrder(String orderId) {
        if (shoppingCart.isEmpty()) {
            throw new IllegalStateException("Cannot place an order with an empty cart.");
        }

        for (Product product : shoppingCart) {
            product.reduceStock(1);
        }

        Order order = new Order(orderId, this, new ArrayList<>(shoppingCart));
        shoppingCart.clear();
        return order;
    }

    @Override
    public String toString() {
        return customerId + " - " + name + " - Cart items: " + shoppingCart.size();
    }
}
