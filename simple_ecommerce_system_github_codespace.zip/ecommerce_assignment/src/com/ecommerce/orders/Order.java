package com.ecommerce.orders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.ecommerce.Customer;
import com.ecommerce.Product;

public class Order {
    public enum OrderStatus {
        PENDING,
        CONFIRMED,
        SHIPPED,
        DELIVERED,
        CANCELLED
    }

    private final String orderId;
    private final Customer customer;
    private final List<Product> products;
    private final double orderTotal;
    private OrderStatus status;

    public Order(String orderId, Customer customer, List<Product> products) {
        if (orderId == null || orderId.trim().isEmpty()) {
            throw new IllegalArgumentException("Order ID cannot be empty.");
        }
        if (customer == null) {
            throw new IllegalArgumentException("Customer cannot be null.");
        }
        if (products == null || products.isEmpty()) {
            throw new IllegalArgumentException("An order must contain at least one product.");
        }

        this.orderId = orderId;
        this.customer = customer;
        this.products = new ArrayList<>(products);
        this.orderTotal = calculateOrderTotal();
        this.status = OrderStatus.PENDING;
    }

    private double calculateOrderTotal() {
        double total = 0.0;
        for (Product product : products) {
            total += product.getPrice();
        }
        return total;
    }

    public String getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<Product> getProducts() {
        return Collections.unmodifiableList(products);
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void updateStatus(OrderStatus newStatus) {
        if (newStatus == null) {
            throw new IllegalArgumentException("Order status cannot be null.");
        }
        this.status = newStatus;
    }

    public String generateSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("\nOrder ID: ").append(orderId);
        summary.append("\nCustomer: ").append(customer.getName());
        summary.append("\nProducts:");

        for (Product product : products) {
            summary.append("\n- ").append(product.getName())
                   .append(" (₦").append(String.format("%.2f", product.getPrice())).append(")");
        }

        summary.append("\nOrder Total: ₦").append(String.format("%.2f", orderTotal));
        summary.append("\nStatus: ").append(status);
        return summary.toString();
    }

    @Override
    public String toString() {
        return "Order " + orderId + " - " + status + " - Total: ₦"
                + String.format("%.2f", orderTotal);
    }
}
