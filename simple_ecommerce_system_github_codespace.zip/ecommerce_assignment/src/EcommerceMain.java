import com.ecommerce.Customer;
import com.ecommerce.Product;
import com.ecommerce.orders.Order;

public class EcommerceMain {
    public static void main(String[] args) {
        System.out.println("===== SIMPLE E-COMMERCE SYSTEM =====");

        Product laptop = new Product("P001", "Laptop", 450000.00, 5);
        Product headphones = new Product("P002", "Wireless Headphones", 35000.00, 10);
        Product mouse = new Product("P003", "Wireless Mouse", 15000.00, 8);

        System.out.println("\n--- Available Products ---");
        System.out.println(laptop);
        System.out.println(headphones);
        System.out.println(mouse);

        Customer customer = new Customer("C001", "Favour");

        System.out.println("\n--- Customer ---");
        System.out.println(customer.getCustomerId() + " - " + customer.getName());

        try {
            System.out.println("\nAdding products to the shopping cart...");
            customer.addProduct(laptop);
            customer.addProduct(headphones);
            customer.addProduct(mouse);

            System.out.println("Cart total: ₦"
                    + String.format("%.2f", customer.calculateTotal()));

            System.out.println("\nCart contents:");
            for (Product product : customer.getShoppingCart()) {
                System.out.println("- " + product.getName()
                        + " (₦" + String.format("%.2f", product.getPrice()) + ")");
            }

            Order order = customer.placeOrder("O001");
            order.updateStatus(Order.OrderStatus.CONFIRMED);

            System.out.println("\n--- Order Details ---");
            System.out.println(order.generateSummary());

            System.out.println("\n--- Updated Product Stock ---");
            System.out.println(laptop);
            System.out.println(headphones);
            System.out.println(mouse);

            System.out.println("\n--- Error Handling Demonstration ---");
            try {
                customer.placeOrder("O002");
            } catch (IllegalStateException e) {
                System.out.println("Handled error: " + e.getMessage());
            }

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("Transaction error: " + e.getMessage());
        }

        System.out.println("\nProgram completed successfully.");
    }
}
